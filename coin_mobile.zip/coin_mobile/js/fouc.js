/*화면깜빡이는 현상*/
$(function(){
  $('html').removeClass('no-js');
});
