<!-- nav_wrap -->
<div id="nav_wrap">
    <!-- nav  -->
    <div id="nav">
        <ul class='nav_list'>
            <li>
              <a href='m_exchange_main.php'>
                <img src="img/chart_on.png" alt="거래소아이콘" class="nav_on"/>
                <!-- <img src="img/chart_off.png" alt="거래소아이콘" class="nav_off"/> -->
                <p class="on">거래소</p>
              </a>
            </li>
            <li>
              <a href='m_account_main.php'>
                <!-- <img src="img/inout_on.png" alt="입출금아이콘" class="nav_on"/> -->
                <img src="img/inout_off.png" alt="입출금아이콘" class="nav_off"/>
                <p>입출금</p>
              </a>
            </li>
            <li>
              <a href='m_mycoin_main.php'>
                <!-- <img src="img/myasset_on.png" alt="자산관리아이콘" class="nav_on"/> -->
                <img src="img/myasset_off.png" alt="자산관리아이콘" class="nav_off"/>
                <p>자산관리</p>
              </a>
            </li>
            <li>
              <a href='m_moreView_main.php'>
                <!-- <img src="img/seemore_on.png" alt="더보기아이콘" class="nav_on"/> -->
                <img src="img/seemore_off.png" alt="더보기아이콘" class="nav_off"/>
                <p>더보기</p>
              </a>
            </li>
        </ul>
    </div>  <!-- nav End-->
</div><!-- nav_wrap End-->
